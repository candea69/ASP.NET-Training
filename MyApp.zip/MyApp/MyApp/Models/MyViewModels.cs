﻿namespace MyApp.Models
{
    public class MyViewModels
    {
        public int Id { get; set; }
        public string Name { get; set; } = null!;
    }
}
